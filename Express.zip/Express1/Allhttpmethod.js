var express= require('express');
var app= express();
app.use(express.json());
app.get("/getAllData",function(req,res){
    console.log("In GET of /getAllData");
    res.send("In GET of /getalldata...");
})
app.post("/insertEmployee",function(req,res){
    var empId =req.body.empId;
    var name= req.body.name;
    var dept =req.body.dept;
    var designation =  req.body.designation;

    console.log(`Given emp Id is ${empId} name is ${name} dept is ${dept} designation is ${designation}`);
    res.send("In POST of /InsertEmployee");
})
app.put("/updateEmployee",function(req,res){
    res.send("In PUT of /updateEmployee");
})
app.delete("/deleteEmployee",function(req,res){

    res.send("In PUT of /deleteEmployee");
})
app.delete("/deleteEmployee/:Id",function(req,res){
    var id =req.params.Id;
    res.send("In DELETE of /deleteEmployee,Deleting the employee record with Id"+id)
})

app.listen(8000,function(){
    console.log("Server is listening")
})
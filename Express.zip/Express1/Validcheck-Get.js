var express =require("express")


var app= express();
app.get ("/login",function(req,res){
    
    console.log("Logging at express running");
    var username=req.query.username;
    var pwd =req.query.password;
    
    console.log(`Given Data is uid: ${username} pwd: ${pwd}`);

      if(username=="sayendeep" &&  pwd=="123")
        res.send("You credentials are correct"); 
      res.send("Your credentials are incorrect");

})
app.listen(8000,function(){
    console.log("Server is listening")
})